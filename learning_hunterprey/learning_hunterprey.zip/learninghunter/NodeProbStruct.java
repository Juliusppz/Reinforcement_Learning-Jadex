package learning_hunterprey.learninghunter;

/**
 *  Author: Julius
 *  
 *  A simple struct to allow grouping of Node references and their probabilities. A simple statistic is 
 *  kept in terms of counts.
 */
public class NodeProbStruct {
	
	public Node node;
	public int prob;
	
	public NodeProbStruct(Node n, int p) {
		node=n;
		prob=p;
	}

}
