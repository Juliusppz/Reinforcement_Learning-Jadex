package learning_hunterprey;

import jadex.base.PlatformConfiguration;
import jadex.base.Starter;
import jadex.bridge.IExternalAccess;

public class Startup
{
	public static void main(String[] args)
	{
		PlatformConfiguration configuration = PlatformConfiguration.getDefaultNoGui();
		configuration.addComponent("learning_hunterprey.HunterPrey.application.xml");
		configuration.setAutoShutdown(true);
		IExternalAccess platform = Starter.createPlatform(configuration).get();
	}
}